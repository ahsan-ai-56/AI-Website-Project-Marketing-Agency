import { Link } from "react-router-dom";
import { Check, Megaphone, Target, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import PageHero from "@/components/PageHero";
import CTASection from "@/components/CTASection";

const channels = [
  { icon: Megaphone, title: "Google Ads", text: "Search, Performance Max, and YouTube campaigns optimized for revenue, not clicks." },
  { icon: Target, title: "Facebook & Instagram Ads", text: "Creative-led Meta campaigns with rigorous testing and conversion tracking." },
  { icon: Sparkles, title: "Campaign Optimization", text: "Continuous experimentation, audience refinement, and creative iteration to compound returns." },
];

const packages = [
  {
    name: "Starter",
    price: "$1,500",
    period: "/mo",
    description: "Perfect for early-stage brands testing paid acquisition.",
    features: ["Up to $10k/mo ad spend", "1 channel (Google or Meta)", "Weekly optimization", "Monthly reporting", "Conversion tracking setup"],
    highlighted: false,
  },
  {
    name: "Growth",
    price: "$3,500",
    period: "/mo",
    description: "For scaling brands ready to dominate paid channels.",
    features: ["Up to $50k/mo ad spend", "Multi-channel (Google + Meta)", "Bi-weekly creative refresh", "Dedicated strategist", "Live performance dashboard", "A/B testing program"],
    highlighted: true,
  },
  {
    name: "Scale",
    price: "Custom",
    period: "",
    description: "Enterprise-grade media buying with full-funnel attribution.",
    features: ["$50k+ /mo ad spend", "All channels + YouTube/TikTok", "Daily optimization", "Senior team + analyst", "Custom attribution modeling", "Quarterly business reviews"],
    highlighted: false,
  },
];

const Ads = () => {
  return (
    <>
      <PageHero
        eyebrow="Paid Advertising"
        title={<>Run ads that <span className="text-gradient">actually print money</span></>}
        description="Profitable Google and Meta campaigns engineered for ROAS — backed by sharp creative and rigorous testing."
        ctaLabel="Run Profitable Ads"
        ctaHref="/contact"
      />

      <section className="container mx-auto py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">Channels we master</span>
          <h2 className="font-display font-bold text-3xl md:text-5xl mt-3">Every dollar accounted for</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {channels.map((c) => (
            <div key={c.title} className="group rounded-2xl border border-border bg-card p-8 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-bounce">
              <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center mb-5 group-hover:scale-110 transition-bounce shadow-elegant">
                <c.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="font-display font-semibold text-xl mb-2">{c.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{c.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="gradient-subtle py-24">
        <div className="container mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Pricing</span>
            <h2 className="font-display font-bold text-3xl md:text-5xl mt-3">Simple, performance-aligned packages</h2>
            <p className="mt-4 text-muted-foreground text-lg">Transparent pricing. Cancel anytime. Always built for ROI.</p>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {packages.map((p) => (
              <div
                key={p.name}
                className={`relative rounded-2xl p-8 border transition-smooth ${
                  p.highlighted
                    ? "gradient-dark text-white border-transparent shadow-elegant scale-100 lg:scale-105"
                    : "bg-card border-border shadow-card hover:shadow-elegant"
                }`}
              >
                {p.highlighted && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-primary-glow text-primary-foreground text-xs font-bold uppercase tracking-wider">
                    Most Popular
                  </span>
                )}
                <h3 className="font-display font-semibold text-2xl">{p.name}</h3>
                <div className="mt-4 flex items-baseline gap-1">
                  <span className="font-display font-bold text-5xl">{p.price}</span>
                  <span className={p.highlighted ? "text-white/70" : "text-muted-foreground"}>{p.period}</span>
                </div>
                <p className={`mt-3 text-sm ${p.highlighted ? "text-white/75" : "text-muted-foreground"}`}>{p.description}</p>
                <ul className="mt-6 space-y-3">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className={`h-5 w-5 shrink-0 ${p.highlighted ? "text-primary-glow" : "text-primary"}`} />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-8">
                  <Button asChild variant={p.highlighted ? "heroOutline" : "default"} className="w-full" size="lg">
                    <Link to="/contact">Get Started</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection title="Run Profitable Ads" description="Tell us your goals and we'll build a custom paid media plan with projected returns." ctaLabel="Get Custom Plan" />
    </>
  );
};

export default Ads;
