import { MailCheck, Workflow, LayoutTemplate, BarChart3 } from "lucide-react";
import PageHero from "@/components/PageHero";
import CTASection from "@/components/CTASection";

const services = [
  { icon: MailCheck, title: "Campaign Strategy", text: "Lifecycle plans mapped to every stage — welcome, nurture, win-back, and loyalty." },
  { icon: Workflow, title: "Automation", text: "Behavior-triggered flows that deliver the right message at the perfect moment, on autopilot." },
  { icon: LayoutTemplate, title: "Newsletter Design", text: "Beautifully designed, on-brand newsletters that subscribers actually look forward to." },
  { icon: BarChart3, title: "Optimization & Reporting", text: "A/B testing, deliverability monitoring, and clear reporting on revenue per send." },
];

const EmailMarketing = () => {
  return (
    <>
      <PageHero
        eyebrow="Email Marketing"
        title={<>Email that builds <span className="text-gradient">relationships and revenue</span></>}
        description="From welcome series to win-back flows, we design email programs that convert subscribers into loyal customers."
        ctaLabel="Start Email Campaigns"
        ctaHref="/contact"
      />

      <section className="container mx-auto py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">What we deliver</span>
          <h2 className="font-display font-bold text-3xl md:text-5xl mt-3">A complete email program, done right</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {services.map((s) => (
            <div key={s.title} className="group rounded-2xl border border-border bg-card p-8 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-bounce flex gap-5">
              <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center shrink-0 shadow-elegant group-hover:scale-110 transition-bounce">
                <s.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-xl mb-2">{s.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{s.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="gradient-subtle py-24">
        <div className="container mx-auto grid gap-8 md:grid-cols-3 text-center">
          {[
            { stat: "42x", label: "Average ROI on email spend" },
            { stat: "+38%", label: "Lift in repeat purchase rate" },
            { stat: "99.2%", label: "Inbox deliverability" },
          ].map((s) => (
            <div key={s.label}>
              <div className="font-display font-bold text-5xl md:text-6xl text-gradient">{s.stat}</div>
              <div className="mt-2 text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      <CTASection title="Start Email Campaigns" description="We'll audit your current program and build a roadmap to unlock its full revenue potential." ctaLabel="Get Email Strategy" />
    </>
  );
};

export default EmailMarketing;
