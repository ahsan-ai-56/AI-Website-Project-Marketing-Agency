import { CheckCircle2, FileSearch, Link2, Wrench } from "lucide-react";
import PageHero from "@/components/PageHero";
import CTASection from "@/components/CTASection";

const pillars = [
  {
    icon: FileSearch,
    title: "On-Page SEO",
    text: "Keyword-led content, optimized meta data, internal linking, and search intent alignment that gets you found.",
    items: ["Keyword research", "Content optimization", "Schema markup", "Internal linking"],
  },
  {
    icon: Link2,
    title: "Off-Page SEO",
    text: "Authority-building backlinks from relevant, high-trust domains using ethical outreach.",
    items: ["Link prospecting", "Digital PR", "Guest posting", "Brand mentions"],
  },
  {
    icon: Wrench,
    title: "Technical SEO",
    text: "Site speed, crawlability, and Core Web Vitals tuned to perfection so search engines love your site.",
    items: ["Core Web Vitals", "Crawl optimization", "Site architecture", "Mobile UX"],
  },
];

const benefits = [
  "Higher rankings for revenue-driving keywords",
  "Sustainable traffic that compounds month over month",
  "Lower customer acquisition costs vs. paid",
  "Authority and trust in your category",
  "Better site UX and conversion rates",
  "Detailed monthly reporting and clear KPIs",
];

const SEOServices = () => {
  return (
    <>
      <PageHero
        eyebrow="SEO Services"
        title={<>Rank higher. Convert more. <span className="text-gradient">Compound growth.</span></>}
        description="Full-service SEO that combines content, links, and technical excellence to drive qualified organic traffic."
        ctaLabel="Improve Your Rankings"
        ctaHref="/contact"
      />

      <section className="container mx-auto py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">Three pillars of SEO</span>
          <h2 className="font-display font-bold text-3xl md:text-5xl mt-3">Built on what actually works</h2>
        </div>
        <div className="grid gap-6 lg:grid-cols-3">
          {pillars.map((p) => (
            <div key={p.title} className="rounded-2xl border border-border bg-card p-8 shadow-card hover:shadow-elegant transition-smooth">
              <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center mb-5 shadow-elegant">
                <p.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="font-display font-semibold text-2xl mb-3">{p.title}</h3>
              <p className="text-muted-foreground mb-5 leading-relaxed">{p.text}</p>
              <ul className="space-y-2">
                {p.items.map((i) => (
                  <li key={i} className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    {i}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="gradient-subtle py-24">
        <div className="container mx-auto grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Benefits & Results</span>
            <h2 className="font-display font-bold text-3xl md:text-5xl mt-3 leading-tight">
              Real <span className="text-gradient">business outcomes</span>, not just rankings
            </h2>
            <p className="mt-4 text-muted-foreground text-lg">
              We track every initiative against revenue and pipeline — because traffic only matters when it converts.
            </p>
          </div>
          <ul className="grid gap-4 sm:grid-cols-2">
            {benefits.map((b) => (
              <li key={b} className="flex gap-3 rounded-xl bg-card border border-border p-5 shadow-soft">
                <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-sm font-medium">{b}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <CTASection title="Improve Your Rankings" description="Get a free SEO audit and a 90-day roadmap to higher rankings and more qualified traffic." ctaLabel="Request Free Audit" />
    </>
  );
};

export default SEOServices;
