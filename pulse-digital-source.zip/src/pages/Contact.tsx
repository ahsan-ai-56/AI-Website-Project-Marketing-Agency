import { useState } from "react";
import { z } from "zod";
import { Mail, Phone, MapPin, Send, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import PageHero from "@/components/PageHero";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be under 100 characters"),
  email: z.string().trim().email("Please enter a valid email").max(255),
  message: z.string().trim().min(10, "Message must be at least 10 characters").max(1000, "Message must be under 1000 characters"),
});

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = contactSchema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach((iss) => {
        if (iss.path[0]) fieldErrors[iss.path[0] as string] = iss.message;
      });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
    toast({ title: "Message sent!", description: "We'll get back to you within one business day." });
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <>
      <PageHero
        eyebrow="Contact"
        title={<>Let's build something <span className="text-gradient">remarkable</span></>}
        description="Tell us about your goals — we'll come back with a clear plan and honest answers."
      />

      <section className="container mx-auto py-24">
        <div className="grid gap-12 lg:grid-cols-5">
          {/* Info */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h2 className="font-display font-bold text-3xl mb-3">Let's Work Together</h2>
              <p className="text-muted-foreground leading-relaxed">
                Whether you need a full-service marketing team or help with a specific channel, we're here to help. Drop us a line and we'll respond within one business day.
              </p>
            </div>

            <div className="space-y-4">
              <a href="mailto:ahsanchilll56@gmail.com" className="flex items-start gap-4 p-5 rounded-xl border border-border bg-card hover:shadow-elegant transition-smooth group">
                <div className="h-11 w-11 rounded-lg gradient-primary flex items-center justify-center shadow-elegant group-hover:scale-110 transition-bounce">
                  <Mail className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Email us</div>
                  <div className="font-semibold">ahsanchilll56@gmail.com</div>
                </div>
              </a>

              <a href="tel:+923269496197" className="flex items-start gap-4 p-5 rounded-xl border border-border bg-card hover:shadow-elegant transition-smooth group">
                <div className="h-11 w-11 rounded-lg gradient-primary flex items-center justify-center shadow-elegant group-hover:scale-110 transition-bounce">
                  <Phone className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Call us</div>
                  <div className="font-semibold">0326 9496197</div>
                </div>
              </a>

              <div className="flex items-start gap-4 p-5 rounded-xl border border-border bg-card">
                <div className="h-11 w-11 rounded-lg gradient-primary flex items-center justify-center shadow-elegant">
                  <MapPin className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Visit us</div>
                  <div className="font-semibold">Gulberg 3, Lahore, Pakistan</div>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="rounded-2xl border border-border bg-card p-8 md:p-10 shadow-card space-y-6">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your full name"
                  className="mt-2 h-12"
                  maxLength={100}
                />
                {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@company.com"
                  className="mt-2 h-12"
                  maxLength={255}
                />
                {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
              </div>

              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Tell us about your goals, channels, and budget..."
                  className="mt-2 min-h-[160px]"
                  maxLength={1000}
                />
                {errors.message && <p className="text-sm text-destructive mt-1">{errors.message}</p>}
              </div>

              <Button type="submit" variant="hero" size="lg" className="w-full">
                {submitted ? <><CheckCircle2 className="h-5 w-5" /> Message Sent</> : <>Send Message <Send className="h-4 w-4" /></>}
              </Button>
              <p className="text-xs text-muted-foreground text-center">We typically respond within one business day.</p>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;
