import { Link } from "react-router-dom";
import { ArrowRight, Share2, Search, Megaphone, Mail, Sparkles, TrendingUp, BarChart3, Users, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import CTASection from "@/components/CTASection";
import heroImage from "@/assets/hero.jpg";

const services = [
  {
    icon: Share2,
    title: "Social Media Marketing",
    description: "Build a magnetic presence with content that converts followers into customers.",
    href: "/social-media-marketing",
  },
  {
    icon: Search,
    title: "SEO Services",
    description: "Climb the rankings and capture high-intent traffic with proven SEO strategies.",
    href: "/seo-services",
  },
  {
    icon: Megaphone,
    title: "Paid Ads",
    description: "Profitable Google & Meta campaigns engineered for maximum ROAS.",
    href: "/ads",
  },
  {
    icon: Mail,
    title: "Email Marketing",
    description: "Automated journeys and newsletters that nurture and convert.",
    href: "/email-marketing",
  },
];

const stats = [
  { value: "250+", label: "Brands Scaled" },
  { value: "$50M+", label: "Revenue Driven" },
  { value: "4.9★", label: "Client Rating" },
  { value: "12+", label: "Years Experience" },
];

const testimonials = [
  {
    quote: "Pulse transformed our funnel — we 4x'd qualified leads in just six months without raising spend.",
    name: "Sarah Chen",
    role: "CMO, Linear Labs",
  },
  {
    quote: "The most strategic agency we've worked with. They feel like an extension of our team.",
    name: "Marcus Reid",
    role: "Founder, Northwind Co.",
  },
  {
    quote: "Their SEO work brought us from page 4 to position 1 for our top keywords. Game-changing.",
    name: "Priya Patel",
    role: "Head of Growth, Helio",
  },
];

const Index = () => {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden gradient-dark text-white">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Abstract digital marketing waves"
            className="h-full w-full object-cover opacity-50"
            width={1920}
            height={1280}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-secondary via-secondary/70 to-transparent" />
        </div>

        <div className="container mx-auto relative py-24 md:py-36 lg:py-44 max-w-3xl">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 border border-white/20 text-xs font-semibold uppercase tracking-wider backdrop-blur-md animate-fade-in">
            <Sparkles className="h-3.5 w-3.5 text-primary-glow" />
            Results-driven digital marketing
          </span>

          <h1 className="font-display font-bold text-5xl md:text-7xl mt-6 leading-[1.05] animate-fade-in-up">
            Grow Your Business with{" "}
            <span className="bg-gradient-to-r from-primary-glow to-white bg-clip-text text-transparent">
              Powerful Digital Marketing
            </span>
          </h1>

          <p className="mt-6 text-lg md:text-xl text-white/80 max-w-2xl leading-relaxed animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            We help brands scale with data-driven strategies across SEO, social, paid media, and email — built to compound month after month.
          </p>

          <div className="mt-10 flex flex-wrap gap-4 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <Button asChild variant="hero" size="xl">
              <Link to="/contact">
                Get Started <ArrowRight className="ml-1 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="heroOutline" size="xl">
              <Link to="/seo-services">Explore Services</Link>
            </Button>
          </div>

          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
            {stats.map((s) => (
              <div key={s.label}>
                <div className="font-display font-bold text-3xl md:text-4xl text-white">{s.value}</div>
                <div className="text-sm text-white/60 mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="container mx-auto py-24" id="services">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">What We Do</span>
          <h2 className="font-display font-bold text-3xl md:text-5xl mt-3">
            Everything you need to <span className="text-gradient">scale</span>
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            Strategy, creative, and execution under one roof — all measured against the metrics that matter.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {services.map((s) => (
            <Link
              key={s.title}
              to={s.href}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card p-7 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-bounce"
            >
              <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center mb-5 group-hover:scale-110 transition-bounce shadow-elegant">
                <s.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="font-display font-semibold text-xl mb-2">{s.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{s.description}</p>
              <div className="mt-5 inline-flex items-center text-sm font-semibold text-primary">
                Learn more
                <ArrowRight className="ml-1 h-4 w-4 group-hover:translate-x-1 transition-smooth" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ABOUT */}
      <section className="gradient-subtle py-24">
        <div className="container mx-auto grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">About Pulse</span>
            <h2 className="font-display font-bold text-3xl md:text-5xl mt-3 leading-tight">
              An agency built around <span className="text-gradient">measurable growth</span>
            </h2>
            <p className="mt-6 text-muted-foreground text-lg leading-relaxed">
              We're a team of strategists, marketers, and creatives obsessed with one thing: outcomes. For over a decade, we've partnered with founders and marketing leaders to build durable, compounding growth engines.
            </p>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              No fluff. No vanity metrics. Just clear strategy, sharp execution, and the dashboards to prove it.
            </p>
            <div className="mt-8">
              <Button asChild size="lg">
                <Link to="/contact">Work with us <ArrowRight className="ml-1 h-4 w-4" /></Link>
              </Button>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {[
              { icon: TrendingUp, title: "Growth-first", text: "Every initiative ladders to revenue, not vanity metrics." },
              { icon: BarChart3, title: "Data-driven", text: "Decisions backed by analytics, attribution, and testing." },
              { icon: Users, title: "Senior team", text: "You work directly with strategists — never juniors." },
              { icon: Sparkles, title: "Creative edge", text: "Brand-worthy creative that actually performs." },
            ].map((f) => (
              <div key={f.title} className="rounded-2xl bg-card border border-border p-6 shadow-card hover:shadow-elegant transition-smooth">
                <div className="h-10 w-10 rounded-lg bg-accent flex items-center justify-center mb-4">
                  <f.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-display font-semibold mb-1">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="container mx-auto py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">Testimonials</span>
          <h2 className="font-display font-bold text-3xl md:text-5xl mt-3">
            Loved by ambitious brands
          </h2>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure
              key={t.name}
              className="rounded-2xl bg-card border border-border p-7 shadow-card hover:shadow-elegant transition-smooth"
            >
              <div className="flex gap-0.5 text-primary mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <blockquote className="text-foreground/90 leading-relaxed">"{t.quote}"</blockquote>
              <figcaption className="mt-6 pt-6 border-t border-border">
                <div className="font-display font-semibold">{t.name}</div>
                <div className="text-sm text-muted-foreground">{t.role}</div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <CTASection
        title="Ready to scale your business?"
        description="Book a free 30-minute strategy call. We'll audit your funnel and show you exactly where the growth is hiding."
        ctaLabel="Book Free Strategy Call"
      />
    </>
  );
};

export default Index;
