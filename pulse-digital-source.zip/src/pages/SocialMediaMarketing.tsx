import { Calendar, MessageCircle, TrendingUp, Camera, Users2, BarChart3 } from "lucide-react";
import PageHero from "@/components/PageHero";
import CTASection from "@/components/CTASection";

const services = [
  { icon: Camera, title: "Content Creation", text: "Scroll-stopping reels, posts, and stories crafted around your brand voice and audience insights." },
  { icon: Calendar, title: "Account Management", text: "Daily publishing, community engagement, and reporting — handled end-to-end by senior managers." },
  { icon: TrendingUp, title: "Growth Strategy", text: "Audience research, content pillars, and posting cadences engineered to compound followers and revenue." },
  { icon: MessageCircle, title: "Community Engagement", text: "Real conversations with your audience that build loyalty and unlock organic reach." },
  { icon: Users2, title: "Influencer Partnerships", text: "Vetted creator collaborations that put your brand in front of high-intent audiences." },
  { icon: BarChart3, title: "Analytics & Reporting", text: "Transparent monthly dashboards showing growth, engagement, and ROI." },
];

const SocialMediaMarketing = () => {
  return (
    <>
      <PageHero
        eyebrow="Social Media Marketing"
        title={<>Build a brand people <span className="text-gradient">can't ignore</span></>}
        description="From bold creative to consistent engagement, we turn your social channels into a reliable growth engine."
        ctaLabel="Boost Your Social Presence"
        ctaHref="/contact"
      />

      <section className="container mx-auto py-24">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">What's included</span>
          <h2 className="font-display font-bold text-3xl md:text-5xl mt-3">A full-stack social team, on tap</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <div key={s.title} className="group rounded-2xl border border-border bg-card p-7 shadow-card hover:shadow-elegant hover:-translate-y-1 transition-bounce">
              <div className="h-12 w-12 rounded-xl gradient-primary flex items-center justify-center mb-5 group-hover:scale-110 transition-bounce shadow-elegant">
                <s.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="font-display font-semibold text-xl mb-2">{s.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="gradient-subtle py-24">
        <div className="container mx-auto grid gap-12 lg:grid-cols-3">
          {[
            { stat: "+312%", label: "Avg. follower growth in 6 months" },
            { stat: "+5.8x", label: "Engagement rate uplift" },
            { stat: "24/7", label: "Community management coverage" },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <div className="font-display font-bold text-5xl md:text-6xl text-gradient">{s.stat}</div>
              <div className="mt-2 text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      <CTASection title="Boost Your Social Presence" description="Let's build a social strategy that actually moves the needle on revenue." ctaLabel="Get a Free Audit" />
    </>
  );
};

export default SocialMediaMarketing;
