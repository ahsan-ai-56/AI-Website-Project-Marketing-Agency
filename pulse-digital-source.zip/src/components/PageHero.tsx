import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PageHeroProps {
  eyebrow: string;
  title: ReactNode;
  description: string;
  ctaLabel?: string;
  ctaHref?: string;
}

const PageHero = ({ eyebrow, title, description, ctaLabel, ctaHref }: PageHeroProps) => {
  return (
    <section className="relative overflow-hidden gradient-dark text-white">
      <div className="absolute inset-0 opacity-40">
        <div className="absolute top-0 left-1/4 h-96 w-96 rounded-full bg-primary/40 blur-3xl animate-glow-pulse" />
        <div className="absolute bottom-0 right-1/4 h-96 w-96 rounded-full bg-primary-glow/30 blur-3xl animate-glow-pulse" style={{ animationDelay: "2s" }} />
      </div>
      <div className="container mx-auto relative py-20 md:py-28 text-center max-w-3xl">
        <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 border border-white/20 text-xs font-semibold uppercase tracking-wider backdrop-blur-md animate-fade-in">
          {eyebrow}
        </span>
        <h1 className="font-display font-bold text-4xl md:text-6xl mt-6 leading-tight animate-fade-in-up">
          {title}
        </h1>
        <p className="mt-6 text-lg text-white/75 leading-relaxed animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
          {description}
        </p>
        {ctaLabel && ctaHref && (
          <div className="mt-8 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <Button asChild variant="hero" size="lg">
              <Link to={ctaHref}>
                {ctaLabel} <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}
      </div>
    </section>
  );
};

export default PageHero;
