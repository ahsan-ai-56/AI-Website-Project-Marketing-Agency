import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CTASectionProps {
  title: string;
  description: string;
  ctaLabel: string;
  ctaHref?: string;
}

const CTASection = ({ title, description, ctaLabel, ctaHref = "/contact" }: CTASectionProps) => {
  return (
    <section className="container mx-auto py-20">
      <div className="relative overflow-hidden rounded-3xl gradient-hero p-10 md:p-16 text-center text-white shadow-elegant">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 right-0 h-72 w-72 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute bottom-0 left-0 h-72 w-72 rounded-full bg-primary-deep/40 blur-3xl" />
        </div>
        <div className="relative max-w-2xl mx-auto">
          <h2 className="font-display font-bold text-3xl md:text-5xl leading-tight">{title}</h2>
          <p className="mt-4 text-lg text-white/85">{description}</p>
          <div className="mt-8">
            <Button asChild variant="heroOutline" size="xl">
              <Link to={ctaHref}>
                {ctaLabel} <ArrowRight className="ml-1 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
