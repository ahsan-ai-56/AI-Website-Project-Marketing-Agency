import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, Zap, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="gradient-dark text-white/80 mt-24">
      <div className="container mx-auto py-16 grid gap-12 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <Link to="/" className="flex items-center gap-2 mb-4">
            <div className="h-9 w-9 rounded-lg gradient-primary flex items-center justify-center">
              <Zap className="h-5 w-5 text-primary-foreground" strokeWidth={2.5} />
            </div>
            <span className="font-display font-bold text-xl text-white">Pulse.</span>
          </Link>
          <p className="text-sm leading-relaxed">
            A digital marketing agency helping ambitious brands scale through data-driven strategy and creative execution.
          </p>
          <div className="flex gap-3 mt-6">
            {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="h-9 w-9 rounded-lg bg-white/10 hover:bg-primary flex items-center justify-center transition-smooth hover:scale-110"
                aria-label="social link"
              >
                <Icon className="h-4 w-4 text-white" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-display font-semibold text-white mb-4">Services</h4>
          <ul className="space-y-3 text-sm">
            <li><Link to="/social-media-marketing" className="hover:text-white transition-smooth">Social Media</Link></li>
            <li><Link to="/seo-services" className="hover:text-white transition-smooth">SEO Services</Link></li>
            <li><Link to="/ads" className="hover:text-white transition-smooth">Paid Ads</Link></li>
            <li><Link to="/email-marketing" className="hover:text-white transition-smooth">Email Marketing</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display font-semibold text-white mb-4">Company</h4>
          <ul className="space-y-3 text-sm">
            <li><Link to="/" className="hover:text-white transition-smooth">Home</Link></li>
            <li><Link to="/contact" className="hover:text-white transition-smooth">Contact</Link></li>
            <li><a href="#" className="hover:text-white transition-smooth">Privacy</a></li>
            <li><a href="#" className="hover:text-white transition-smooth">Terms</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-display font-semibold text-white mb-4">Get in Touch</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex items-start gap-3">
              <Mail className="h-4 w-4 mt-1 text-primary-glow shrink-0" />
              <a href="mailto:ahsanchilll56@gmail.com" className="hover:text-white transition-smooth">ahsanchilll56@gmail.com</a>
            </li>
            <li className="flex items-start gap-3">
              <Phone className="h-4 w-4 mt-1 text-primary-glow shrink-0" />
              <a href="tel:+923269496197" className="hover:text-white transition-smooth">0326 9496197</a>
            </li>
            <li className="flex items-start gap-3">
              <MapPin className="h-4 w-4 mt-1 text-primary-glow shrink-0" />
              <span>Gulberg 3, Lahore, Pakistan</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container mx-auto py-6 text-sm text-white/60 flex flex-col sm:flex-row justify-between gap-2">
          <p>© {new Date().getFullYear()} Pulse Digital. All rights reserved.</p>
          <p>Crafted with precision for growing brands.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
